function z=ANDF(a,b) %function creation

if a==1                     %first we select a = 1 and find out 
    if b==1             %all possible combinations by assigning values to b
        z=1;
    elseif b==0
        z=0;
    else
        z=('Enter only binary,Restart the process manually');
    end
else
if a==0                      %Likewise we assign a = 0 and find out all possile
    if b==1                  %combinations by assigning the values to b
        z=0;
    elseif b==0
        z=0;
    else
        z=('Enter only binary,Restart the process manually');
    end
else
    z=('Enter only binary,Restart the process manually');
end
end
end