function z=NORF(a,b) 
if (a==1||a==0 && b==1||b==0)%FUNCTION CREATION
 s = ORF(a,b);          %NOR FUNCTION IS BASICALLY NOT(OR)
 z = NOTF(s);
else 
    z=("invalid");
end

