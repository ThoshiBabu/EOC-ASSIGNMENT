function z=XNORF(a,b)
if (a==1||a==0 && b==1||b==0)%FUNCTION CREATION
x = NOTF(a);
y = NOTF(b); %WE KNOW THAT ACCORDING TO THE TRUTH TABLE 
                 %THE  FORMULA IS A'B'+AB
                %THATS WHY WE USE 2 NOT GATES 2 AND GATES AND 1 OR GATE
s = ANDF(a,b);
t = ANDF(x,y);
z = ORF(s,t);
else 
    z=("invalid");
end
                  