function [fh,fhcarry]=Fulladder(a,b,c)
fh=XORF(XORF(a,b),c)
fhcarry=ORF(ANDF(a,b),ANDF(b,c),ANDF(c,a))
end