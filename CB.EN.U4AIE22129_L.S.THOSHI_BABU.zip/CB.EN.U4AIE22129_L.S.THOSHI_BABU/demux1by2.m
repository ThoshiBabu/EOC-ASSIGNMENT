function [a,b]=demux1by2(sel,in)
a=ANDF(NOTF(sel),in)
b=ANDF(sel,in)
end
