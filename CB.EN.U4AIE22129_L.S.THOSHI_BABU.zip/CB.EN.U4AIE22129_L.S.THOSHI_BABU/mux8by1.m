function mux8=mux8by1(s0,s1,s2,d0,d1,d2,d3,d4,d5,d6,d7)
mux8=mux2by1(s2,mux4by1(s0,s1,d0,d1,d2,d3),mux4by1(s0,s1,d4,d5,d6,d7))
end
